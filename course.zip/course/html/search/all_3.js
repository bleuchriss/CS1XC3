var searchData=
[
  ['enroll_5fstudent_0',['enroll_student',['../course_8c.html#af3abbc650ef56ffff427a62dad63fc77',1,'enroll_student(Course *course, Student *student):&#160;course.c'],['../course_8h.html#af3abbc650ef56ffff427a62dad63fc77',1,'enroll_student(Course *course, Student *student):&#160;course.c']]]
];
