/**
 * @file student.c
 * @author Christopher Singh (singhc32)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to the students record
 * 
 * @param student The stuent the grade is being added to
 * @param grade The grade being added to the student
 */
void add_grade(Student* student, double grade)
{
  // Increase the amount of grades the student has
  student->num_grades++;
  // If there were not grades for the student, initialize the size of grade to 1 using calloc
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  // Otherwise, reallocate memory to the size of new number of grade using realloc
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // Adds the grade
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Returns the average grade of a student
 * 
 * @param student The student 
 * @return double The average grade of the student
 */
double average(Student* student)
{
  // Return 0 if the student has no grades
  if (student->num_grades == 0) return 0;

  // Calculation for total grades
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];

  // Return the average grade of the student
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints the students first name, last name, id, grades, and average
 * 
 * @param student The student
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // Loops through all grades of the student and prints every grade
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Generates a random student with a first name, last name, id, and grades
 * 
 * @param grades The amount of grades
 * @return Student* The student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  // Initialize memory for new student using calloc
  Student *new_student = calloc(1, sizeof(Student));

  // Sets the students first and last name
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Generates a random id for the student
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Generates random grades for the new student 
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  // Return the new student
  return new_student;
}