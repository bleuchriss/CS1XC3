/**
 * @file course.h
 * @author Christopher Singh (singhc32)
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief A struct that contains the name, code, list of students, and number of students of a course
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

// Functions declarations
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


