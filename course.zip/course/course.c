/**
 * @file course.c
 * @author Christopher Singh (singhc32)
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Enrolls a student into a course
 * 
 * @param course The course the student is being enrolled in
 * @param student The student that is being enrolled
 */
void enroll_student(Course *course, Student *student)
{
  // Increase the number of students in the course
  course->total_students++;
  // If there were no students in a course, initialize the size to 1 using calloc
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  // Otherwise, reallocate memory to the size of the new list of students using realloc
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Adds the new student
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints out the course name, code, # of students, and every student enrolled in the course
 * 
 * @param course The course that is printed out
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // Loops through every student in the course and prints it out
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returns the student with the highest average in the course
 * 
 * @param course The course to check for the top student
 * @return Student* The student with the best average in the course
 */
Student* top_student(Course* course)
{
  // If there are no student in the course, return NULL
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  // Initializes the max average to the first student in the course
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // Loops through all students in the course to find the student with the highest average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    // If the student average is greater than the current max average, set the max average to the student average\
    // and set student to the new student with the highest average 
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Returns all the students in a course that are passing (50% or above)
 * 
 * @param course The course to check which students are passing or not
 * @param total_passing The number of total passing students
 * @return Student* The list of students that are passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;

  // Increment count for every student that has an average of 50 or more
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // Initialize passing using calloc to the amount of passing students
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // Loops through all students in the course, and adds the student to passing if they have an average of 50 or more
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}